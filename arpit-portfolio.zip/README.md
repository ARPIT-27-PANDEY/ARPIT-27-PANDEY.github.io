# Arpit Kumar Pandey — Portfolio

A lightweight, responsive personal portfolio website for Arpit Kumar Pandey.

## Stack

- HTML5
- CSS3
- Vanilla JavaScript
- No external UI framework or dependency

## Sections

- About
- Experience
- Projects
- Leadership & Extracurriculars
- Achievements
- Technical Skills
- Education
- Contact

## Run locally

No build step is required.

```bash
python -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

## Deploy with GitHub Pages

1. Create a GitHub repository (for example, `arpit-portfolio`).
2. Upload the contents of this folder to the repository root.
3. In **Settings → Pages**, select:
   - Source: **Deploy from a branch**
   - Branch: `main`
   - Folder: `/ (root)`
4. Save the configuration.
5. GitHub Pages will publish the site at the generated Pages URL.

### Optional profile-site repo

For a personal site under the standard GitHub Pages pattern, a repository named:

```text
ARPIT-27-PANDEY.github.io
```

can be used.

## Resume

The site includes a copy of the supplied resume at:

```text
assets/Arpit-Kumar-Pandey-Resume.pdf
```

## Notes

The content is intentionally conservative and based on the supplied resume/profile and the project repositories already referenced by the portfolio. No extra job titles, metrics, companies, certifications, or technologies are added beyond those sources.
